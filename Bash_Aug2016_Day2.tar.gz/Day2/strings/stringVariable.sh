#!/bin/bash

#This script demonstrate how to create and
#display a string

b="kdsidfd"
echo $b

a=dkii122d
echo $a

c='dkii122d'
echo $c

