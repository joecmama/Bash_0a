#!/bin/bash

## Compare Integers
## Modify and check with negative
## or float point numbers

a=4
b=3

if (( a > b ))
then
  echo "$a > $b"
else
  echo "$a<=$b"
fi


if [[ $a -gt $b ]]
then
  echo "$a > $b"
else
  echo "$a<=$b"
fi

if [ $a -gt $b ]
then
  echo "$a > $b"
else
  echo "$a<=$b"
fi

a=4
b=31
if [[ $a > $b ]]
then 
  echo "$a > $b"
else
  echo "$a <= $b"
fi

