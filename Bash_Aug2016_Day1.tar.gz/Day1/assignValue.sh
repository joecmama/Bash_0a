#!/bin/bash

x="apple"

echo "my favorite fruit is ${x}s"

y=${x}

echo $y

z=$(date)
#z=`date`
echo $z

c=`ls`

a=$(( 1+2 ))

echo $a
