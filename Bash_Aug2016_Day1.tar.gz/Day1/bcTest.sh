#!/bin/bash

echo "s(3.1415926)" | bc -l
