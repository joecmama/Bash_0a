#!/bin/bash

# this is our first bash script


a=1
b=2.3
c="A string"
d=$b

echo "hello class"
echo "$d $a"
echo '$d $a'
